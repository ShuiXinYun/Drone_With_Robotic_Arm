﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Kinect;
using Coding4Fun.Kinect.Wpf;

namespace Kinect
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        KinectSensor kinectsensor;
        private Skeleton[] skeletondata;
        double[,] leftarmToARM = new double[2, 3];//存储大臂&小臂向量信息，this matrix contains the vector information of  forearm&aftarm(left)
        double[,] left = new double[4, 3];//this matrix contains the X,Y,Z position of shoulderleft, elbowleft, wristleft, handleft
        double[,] ARM_left_projectToXYplane = new double[2, 3];//包含大臂投影到XY面的向量和向量(0,1,0)，大臂旋转分解为两次，此为第一次
        double[,] ARM_left_ToARMprojectVector_InXY = new double[2, 3];//包含大臂空间向量和投影向量
        double[,] Head = new double[2, 3];
        double angleleftarmToARM;//大臂、小臂之间夹角the angle between left forearm&aftarm
        double angle_left_ARM_rotateInXYplane;//大臂旋转角度1
        double angle_left_ARM_rotateInXZplane;//大臂旋转角度2
        double angle_Head;
        string[] angle_info = new string[6];
        string[] elbow_info = new string[3];
        Boolean isrecord = true;
        StreamWriter sw = new StreamWriter("D:\\kinect_angle.txt");
        StreamWriter sw0 = new StreamWriter("D:\\kinect_elbowxyz.txt");
        DateTime beforDT = System.DateTime.Now;
        short[] pixeldata;
        byte[] colorpixledata;

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            kinectsensor = (from sensor in KinectSensor.KinectSensors where sensor.Status == KinectStatus.Connected select sensor).FirstOrDefault();
            //kinectsensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;
            kinectsensor.DepthStream.Enable(DepthImageFormat.Resolution80x60Fps30);
            kinectsensor.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
            kinectsensor.Start();
            kinectsensor.ElevationAngle = 0;
            /*
            var parameters = new TransformSmoothParameters
            {
                Smoothing = 0.6f,
                Correction = 0.4f,
                Prediction = 0.5f,
                JitterRadius = 0.01f,
                MaxDeviationRadius = 0.01f
            };
            */
            kinectsensor.SkeletonStream.Enable();
             
            kinectsensor.DepthFrameReady += kinectsensor_DepthFrameReady;
            kinectsensor.ColorFrameReady += kinectsensor_ColorFrameReady;
            kinectsensor.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(kinectsensor_SkeletonFrameReady);
        }

        void kinectsensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (ColorImageFrame colorframe = e.OpenColorImageFrame())
            {
                if (colorframe != null)
                {
                    this.colorpixledata = new byte[colorframe.PixelDataLength];
                    colorframe.CopyPixelDataTo(this.colorpixledata);
                    this.ColorImage.Source = BitmapSource.Create(colorframe.Width, colorframe.Height, 96, 96, PixelFormats.Bgr32, null, colorpixledata, colorframe.Width * colorframe.BytesPerPixel);
                }
            }
        }

        void kinectsensor_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        {
            using (DepthImageFrame depthframe = e.OpenDepthImageFrame())
            {
                if (depthframe != null)
                {
                    this.pixeldata = new short[depthframe.PixelDataLength];
                    depthframe.CopyPixelDataTo(this.pixeldata);
                    this.DepthImage.Source = BitmapSource.Create(depthframe.Width, depthframe.Height, 96, 96, PixelFormats.Gray16, null, pixeldata, depthframe.Width * depthframe.BytesPerPixel);
                }
            }
        }

        private void kinectsensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (SkeletonFrame skeletonframe = e.OpenSkeletonFrame())
            {
                if (skeletonframe != null)
                {
                    Kinect_Pitch.Content = kinectsensor.ElevationAngle.ToString();
                    skeletondata = new Skeleton[kinectsensor.SkeletonStream.FrameSkeletonArrayLength];
                    skeletonframe.CopySkeletonDataTo(this.skeletondata);
                    Skeleton skeleton = (from s in skeletondata where s.TrackingState == SkeletonTrackingState.Tracked select s).FirstOrDefault();
                    if (skeleton != null)
                    {
                        setallpointposition(skeleton);
                    }
                }
            }
        }
        private Point getdisplaypoint(Joint joint)
        {
            var scaledjoint = joint.ScaleTo(640, 480);
            return new Point(scaledjoint.Position.X, scaledjoint.Position.Y);
        }

        private void setpointposition(FrameworkElement ellipse, Joint joint)
        {
            var scaledjoint = joint.ScaleTo(640, 480);
            Canvas.SetLeft(ellipse, scaledjoint.Position.X);
            Canvas.SetTop(ellipse, scaledjoint.Position.Y);
            SkeletonCanvas.Children.Add(ellipse);
        }

        Polyline headpolyline = new Polyline();
        Polyline handleftpolyline = new Polyline();
        Polyline handrightpolyline = new Polyline();
        Polyline spinepolyline = new Polyline();
        private double anglecaculate(double[,] a)
        {
            double abvect = a[0, 0] * a[1, 0] + a[0, 1] * a[1, 1] + a[0, 2] * a[1, 2];
            double adist = Math.Sqrt(a[0, 0] * a[0, 0] + a[0, 1] * a[0, 1] + a[0, 2] * a[0, 2]);
            double bdist = Math.Sqrt(a[1, 0] * a[1, 0] + a[1, 1] * a[1, 1] + a[1, 2] * a[1, 2]);
            double angle = Math.Acos(abvect / (adist * bdist));
            return angle;
        }
        private void setallpointposition(Skeleton skeleton)
        {
            SkeletonCanvas.Children.Clear();
            headpolyline.Points.Clear();
            handleftpolyline.Points.Clear();
            handrightpolyline.Points.Clear();
            spinepolyline.Points.Clear();
            foreach (Joint joint in skeleton.Joints)
            {
                Point jointpoint = getdisplaypoint(joint);
                switch (joint.JointType)
                {
                    case JointType.Head:
                        Head[0, 0] = joint.Position.X;
                        Head[0, 1] = joint.Position.Y;
                        Head[0, 2] = 0;
                        setpointposition(headpoint, joint);
                        headpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.ShoulderCenter:
                        Head[0, 0] = Head[0, 0] - joint.Position.X;
                        Head[0, 1] = Head[0, 1] - joint.Position.Y;
                        Head[1, 0] = 1;
                        Head[1, 1] = 0;
                        Head[1, 2] = 0;
                        angle_Head = 180 - anglecaculate(Head) * 180 / 3.14159;
                        Head_Rotate.Content = angle_Head.ToString("F3");
                        setpointposition(shouldercenterpoint, joint);
                        headpolyline.Points.Add(jointpoint);
                        handleftpolyline.Points.Add(jointpoint);
                        handrightpolyline.Points.Add(jointpoint);
                        spinepolyline.Points.Add(jointpoint);
                        break;
                    case JointType.ShoulderLeft:
                        left[0, 0] = joint.Position.X;
                        left[0, 1] = joint.Position.Y;
                        left[0, 2] = joint.Position.Z;
                        setpointposition(shoulderleftpoint, joint);
                        handleftpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.ElbowLeft:
                        left[1, 0] = joint.Position.X;
                        left[1, 1] = joint.Position.Y;
                        left[1, 2] = joint.Position.Z;
                        DateTime afterDT = System.DateTime.Now;
                        TimeSpan dt = afterDT.Subtract(beforDT);
                        Runtime.Content = (dt.TotalMilliseconds*0.001).ToString("F3");
                        if (isrecord)
                        {
                            elbow_info[0] = joint.Position.X.ToString("F2");
                            elbow_info[1] = joint.Position.Y.ToString("F2");
                            elbow_info[2] = joint.Position.Z.ToString("F2");
                            sw0.WriteLine((dt.TotalMilliseconds * 0.001).ToString("F3") + "    " + elbow_info[0] + "    " + elbow_info[1] + "    " + elbow_info[2]);
                        }
                        setpointposition(elbowleftpoint, joint);
                        handleftpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.WristLeft:
                        left[2, 0] = joint.Position.X;
                        left[2, 1] = joint.Position.Y;
                        left[2, 2] = joint.Position.Z;
                        setpointposition(wristleftpoint, joint);
                        handleftpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.HandLeft:
                        left[3, 0] = joint.Position.X;
                        left[3, 1] = joint.Position.Y;
                        left[3, 2] = joint.Position.Z;
                        leftarmToARM[0, 0] = left[0, 0] - left[1, 0];
                        ARM_left_ToARMprojectVector_InXY[1, 0] = left[0, 0] - left[1, 0];
                        leftarmToARM[0, 1] = left[0, 1] - left[1, 1];
                        ARM_left_ToARMprojectVector_InXY[1, 1] = left[0, 1] - left[1, 1];
                        leftarmToARM[0, 2] = left[0, 2] - left[1, 2];
                        ARM_left_ToARMprojectVector_InXY[1, 2] = left[0, 2] - left[1, 2];
                        leftarmToARM[1, 0] = left[1, 0] - left[2, 0];
                        leftarmToARM[1, 1] = left[1, 1] - left[2, 1];
                        leftarmToARM[1, 2] = left[1, 2] - left[2, 2];
                        angleleftarmToARM = 180 - anglecaculate(leftarmToARM) * 180 / 3.14159;
                        ARM_left_projectToXYplane[0, 0] = left[1, 0] - left[0, 0];
                        ARM_left_ToARMprojectVector_InXY[0, 0] = left[1, 0] - left[0, 0];
                        ARM_left_projectToXYplane[0, 1] = left[1, 1] - left[0, 1];
                        ARM_left_ToARMprojectVector_InXY[0, 1] = left[1, 1] - left[0, 1];
                        ARM_left_projectToXYplane[0, 2] = 0;
                        ARM_left_projectToXYplane[1, 0] = 0;
                        ARM_left_projectToXYplane[1, 1] = 1;
                        ARM_left_projectToXYplane[1, 2] = 0;
                        if (left[0, 0] > left[1, 0])
                        {
                            angle_left_ARM_rotateInXYplane = 180 - anglecaculate(ARM_left_projectToXYplane) * 180 / 3.14159;
                        }
                        else
                        {
                            angle_left_ARM_rotateInXYplane = anglecaculate(ARM_left_projectToXYplane) * 180 / 3.14159 - 180;
                        }
                        if (left[0, 2] > left[1, 2])
                        {
                            angle_left_ARM_rotateInXZplane = 180 - anglecaculate(ARM_left_ToARMprojectVector_InXY) * 180 / 3.14159;
                        }
                        else
                        {
                            angle_left_ARM_rotateInXZplane = anglecaculate(ARM_left_ToARMprojectVector_InXY) * 180 / 3.14159 - 180;
                        }
                        L_Arm12_Angle.Content = angleleftarmToARM.ToString("F3");                       
                        Arm1_Angle1.Content = angle_left_ARM_rotateInXYplane.ToString("F3"); 
                        Arm1_Angle2.Content = angle_left_ARM_rotateInXZplane.ToString("F3");
                        if(isrecord)
                        {
                            angle_info[0] = angleleftarmToARM.ToString("F3");
                            angle_info[1] = angle_left_ARM_rotateInXYplane.ToString("F3");
                            angle_info[2] = angle_left_ARM_rotateInXZplane.ToString("F3");
                            DateTime afterDT1 = System.DateTime.Now;
                            TimeSpan dt1 = afterDT1.Subtract(beforDT);
                            sw.WriteLine((dt1.TotalMilliseconds * 0.001).ToString("F3") + "    " + angle_info[0] + "    " + angle_info[1] + "    "+ angle_info[2]);
                        }
                        setpointposition(handleftpoint, joint);
                        handleftpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.ShoulderRight:
                        setpointposition(shoulderrightpoint, joint);
                        handrightpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.ElbowRight:
                        setpointposition(elbowrightpoint, joint);
                        handrightpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.WristRight:
                        setpointposition(wristrightpoint, joint);
                        handrightpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.HandRight:
                        setpointposition(handrightpoint, joint);
                        handrightpolyline.Points.Add(jointpoint);
                        break;
                    case JointType.Spine:
                        setpointposition(spinepoint, joint);
                        spinepolyline.Points.Add(jointpoint);
                        break;
                }
            }

            headpolyline.Stroke = new SolidColorBrush(Colors.Blue);
            headpolyline.StrokeThickness = 5;
            SkeletonCanvas.Children.Add(headpolyline);
            handleftpolyline.Stroke = new SolidColorBrush(Colors.Blue);
            handleftpolyline.StrokeThickness = 5;
            SkeletonCanvas.Children.Add(handleftpolyline);
            handrightpolyline.Stroke = new SolidColorBrush(Colors.Blue);
            handrightpolyline.StrokeThickness = 5;
            SkeletonCanvas.Children.Add(handrightpolyline);
            spinepolyline.Stroke = new SolidColorBrush(Colors.Blue);
            spinepolyline.StrokeThickness = 5;
            SkeletonCanvas.Children.Add(spinepolyline);
        }

        private void Button_Click_1_plus(object sender, RoutedEventArgs e)
        {
            if (kinectsensor.ElevationAngle + 5 > kinectsensor.MaxElevationAngle)
            {
                kinectsensor.ElevationAngle = kinectsensor.MaxElevationAngle;
            }
            else
            {
                kinectsensor.ElevationAngle = kinectsensor.ElevationAngle + 5;
            }
        }

        private void Button_Click_decrease(object sender, RoutedEventArgs e)
        {
            if (kinectsensor.ElevationAngle - 5 < kinectsensor.MinElevationAngle)
            {
                kinectsensor.ElevationAngle = kinectsensor.MinElevationAngle;
            }
            else
            {
                kinectsensor.ElevationAngle = kinectsensor.ElevationAngle - 5;
            }
        }

    }
}
