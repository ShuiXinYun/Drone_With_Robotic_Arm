# stm32f10x_template_no_rtos
template for stm32f10x project
