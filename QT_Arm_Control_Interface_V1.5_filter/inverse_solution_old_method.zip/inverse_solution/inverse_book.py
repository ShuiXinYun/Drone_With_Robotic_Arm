# -*- coding: utf-8 -*-
"""
Created on Sun May  8 22:13:47 2016
@author: shuixin
"""

from math import *
#import os
import numpy as np

def inverse_angle(nx,ox,ax,px,ny,oy,ay,py,nz,oz,az,pz,a2,a3,a4,mode):
    try:
        if mode[0]==0:
            theta1=atan(py/px)-pi
        elif mode[0]==1:
            theta1=atan(py/px)
        elif mode[0]==2:
            theta1=atan(py/px)+pi
            
        if mode[1]==0:
                theta234=atan(az/(cos(theta1)*ax+sin(theta1)*ay))-pi
        elif mode[1]==1:
                theta234=atan(az/(cos(theta1)*ax+sin(theta1)*ay))
        elif mode[1]==2:
                theta234=atan(az/(cos(theta1)*ax+sin(theta1)*ay))+pi
        #print "theta234  ",theta234
        costheta3=(pow((px*cos(theta1)+py*sin(theta1)-cos(theta234)*a4),2)+pow((pz-sin(theta234)*a4),2)-a2*a2-a3*a3)/(2*a2*a3)
        if mode[2]==0:
            theta3=acos(costheta3)-pi
        elif mode[2]==1:
            theta3=acos(costheta3)
        elif mode[2]==2:
            theta3=acos(costheta3)+pi
        '''
        if costheta3>1 or costheta3<-1:
            theta234=3.1415926+atan(az/(cos(theta1)*ax+sin(theta1)*ay))
            costheta3=(pow((px*cos(theta1)+py*sin(theta1)-cos(theta234)*a4),2)+pow((pz-sin(theta234)*a4),2)-a2*a2-a3*a3)/(2*a2*a3)
        #print "costheta3  ",costheta3
        
        if mode in [0,2,4,6,8,10,12,14,16]:
            sintheta3=sqrt(1.0-pow(costheta3,2))
        else:
            sintheta3=-sqrt(1.0-pow(costheta3,2))
        theta3=atan(sintheta3/costheta3)
        '''
        theta2up=(cos(theta3)*a3+a2)*(pz-sin(theta234)*a4)-sin(theta3)*a3*(px*cos(theta1)+py*sin(theta1)-cos(theta234)*a4)
        theta2low=(cos(theta3)*a3+a2)*(px*cos(theta1)+py*sin(theta1)-cos(theta234)*a4)+sin(theta3)*a3*(pz-sin(theta234)*a4)
        if mode[3]==0:
            theta2=atan(theta2up/theta2low)-pi
        elif mode[3]==1:
            theta2=atan(theta2up/theta2low)
        elif mode[3]==2:
            theta2=atan(theta2up/theta2low)+pi
            
        theta4=theta234-theta2-theta3
        
        theta5up=(cos(theta234)*(cos(theta1)*ax+sin(theta1)*ay)+sin(theta234)*az)
        theta5low=(sin(theta1)*ax-cos(theta1)*ay)
        if mode[4]==0:
            theta5=atan(theta5up/theta5low)-pi
        elif mode[4]==1:
            theta5=atan(theta5up/theta5low)
        elif mode[4]==2:
            theta5=atan(theta5up/theta5low)+pi
        theta6up=-sin(theta234)*(cos(theta1)*nx+sin(theta1)*ny)+cos(theta234)*nz    
        #theta6low=-sin(theta234)*(cos(theta1)*ox+sin(theta1)*ny)+cos(theta234)*oz
        theta6low=(cos(theta5)*(cos(theta234)*(cos(theta1)*nx+sin(theta1)*ny)+sin(theta234)*nz)-sin(theta5)*(sin(theta1)*nx-cos(theta1)*ny))
        if mode[5]==0:
            theta6=atan(theta6up/theta6low)-pi
        elif mode[5]==1:
            theta6=atan(theta6up/theta6low)
        elif mode[5]==2:
            theta6=atan(theta6up/theta6low)+pi
        theta=[theta1,theta2,theta3,theta4,theta5,theta6]
        return theta
    except:
        pass
  
def forward_kine(t1,t2,t3,t4,t5,t6,a2,a3,a4):
    A1=np.matrix([[cos(t1),0,sin(t1),0],[sin(t1),0,-cos(t1),0],[0,1,0,0],[0,0,0,1]])
    A2=np.matrix([[cos(t2),-sin(t2),0,cos(t2)*a2],[sin(t2),cos(t2),0,sin(t2)*a2],[0,0,1,0],[0,0,0,1]])
    A3=np.matrix([[cos(t3),-sin(t3),0,cos(t3)*a3],[sin(t3),cos(t3),0,sin(t3)*a3],[0,0,1,0],[0,0,0,1]])
    A4=np.matrix([[cos(t4),0,-sin(t4),cos(t4)*a4],[sin(t4),0,cos(t4),sin(t4)*a4],[0,-1,0,0],[0,0,0,1]])
    A5=np.matrix([[cos(t5),0,sin(t5),0],[sin(t5),0,-cos(t5),0],[0,1,0,0],[0,0,0,1]])
    A6=np.matrix([[cos(t6),-sin(t6),0,0],[sin(t6),cos(t6),0,0],[0,0,1,0],[0,0,0,1]])
    #print "tans_inverse:"
    A=A1*A2*A3*A4*A5*A6
    #print A
    return A
    '''
    t234=t2+t3+t4
    t23=t2+t3
    t11=cos(t1)*(cos(t234)*cos(t5)*cos(t6)-sin(t234)*sin(t6))-sin(t1)*sin(t5)*cos(t6)
    #print "t11:",t11
    t12=cos(t1)*(-cos(t234)*cos(t5)*cos(t6)-sin(t234)*cos(t6))+sin(t1)*sin(t5)*sin(t6)
    #print "t12:",t12
    t13=cos(t1)*(cos(t234)*sin(t5))+sin(t1)*cos(t5)
    #print "t13:",t13
    t14=cos(t1)*(cos(t234)*a4+cos(t23)*a3+cos(t2)*a2)
    #print "t14:",t14
    t21=sin(t1)*(cos(t234)*cos(t5)*cos(t6)-sin(t234)*sin(t6))+cos(t1)*sin(t5)*sin(t6)
    #print "t21:",t21
    t22=sin(t1)*(-cos(t234)*cos(t5)*cos(t6)-sin(t234)*cos(t6))-cos(t1)*sin(t5)*sin(t6)
    #print "t22:",t22
    t23=sin(t1)*cos(t234)*sin(t5)-cos(t1)*cos(t5)
    #print "t23:",t23
    t24=sin(t1)*(cos(t234)*a4+cos(t23)*a3+cos(t2)*a2)
    #print "t24:",t24
    t31=sin(t234)*cos(t5)*cos(t6)+cos(t234)*sin(t6)
    #print "t31:",t31
    t32=-sin(t234)*cos(t5)*cos(t6)+cos(t234)*cos(t6)
    #print "t32:",t32
    t33=sin(t234)*sin(t5)
    #print "t33:",t33
    t34=sin(t234)*a4+sin(t23)*a3+sin(t2)*a2
    #print "t34:",t34
    t_inverse=np.array([[t11,t12,t13,t14],[t21,t22,t23,t24],[t31,t32,t33,t34]])
    print "tans_inverse:"
    print t_inverse
    '''
    
def compare_error(A,T):
    error=0
    for i in range(4) :
        for j in range(3):
            error+=abs(A[j,i]-T[j,i])
    return error

#ang=inverse_angle(0.9890,-0.0992,0.1098,0.9257,0.1092,-0.0110,-0.9940,0.0093,0.0998,0.9950,0.0000,-1.4489,1.0,1.0,0.5)#[0.01 -2 1.43 0.57 0.1 0.1]
#ang=inverse_angle(1.0000,0.0000,0.0000,0.9258,-0.0000,0.0000,-1.0000,0.0000,0.0000,1.0000,0.0000,-1.4489,1.0,1.0,0.5) #[0 -2 1.43 0.57 0 0]
#ang=inverse_angle(-0.6029,0.7978,0.0045,-0.2004,-0.0975,-0.068,-0.9929,-0.3121,-0.7919,-0.5991,0.1187,1.8213,1.0,1.0,0.5) #[1 1 1 1 1 1]
#ang=inverse_angle(0.4830,0.6867,0.5433,2.4405,0.4461,0.3410,-0.8275,0.2449,-0.7535,0.6420,-0.1417,-0.2466,1.0,1.0,0.5) #[[0.1 -0.2 0.3 -0.4 0.5 -0.6]]
#print ang
def inverse_forward_error(forward,armstate,mode):
    try:
        Error=[mode,10000]
        inverse_solve=forward_kine(armstate[0],armstate[1],armstate[2],
                                   armstate[3],armstate[4],armstate[5],
                                   armstate[6],armstate[7],armstate[8])
        Error[1]=compare_error(forward,inverse_solve)    
        return Error
    except:
        pass

def inverse_result_filter(forward,a2,a3,a4):
    try:
        Errorlist=[]
        Errorlist1=[]
        for m0 in xrange(3):
            for m1 in xrange(3):
                for m2 in xrange(3):
                    for m3 in xrange(3):
                        for m4 in xrange(3):
                            for m5 in xrange(3):
                                i=[m0,m1,m2,m3,m4,m5]
                                armstate=inverse_angle(forward[0,0],forward[0,1],forward[0,2],forward[0,3],
                                          forward[1,0],forward[1,1],forward[1,2],forward[1,3],
                                          forward[2,0],forward[2,1],forward[2,2],forward[2,3],
                                          a2,a3,a4,i)
                                if armstate!=None:
                                    armstate=armstate+[a2,a3,a4]
                                    Error=inverse_forward_error(forward,armstate,i)
                                    Errorlist.append(Error[0])
                                    Errorlist1.append(Error[1])
        Errorminindex=Errorlist1.index(min(Errorlist1))
        mode_min=Errorlist[Errorminindex]
        return mode_min
    except:
        pass

#forward=forward_kine(0.5,0.3,0.4,0.6,0.5,1,0.25,0.26,0.08)
def angle_standard(solution):
    solution_standard=[]
    for i in solution:
        if abs(i-3.1415926)<1e-6:
            i=3.14159
        elif abs(i+3.1415926)<1e-6:
            i=-3.14159
        elif i>pi:
            i=i-2*pi
        elif i<-pi:
            i=i+2*pi
        solution_standard.append(i)
    return solution_standard
            

def angle_run(px,py,pz):    
    forward=np.matrix([[1e-6,1e-6,1e-6,px],
                       [1e-6,1e-6,1e-6,py],
                       [1e-6,1e-6,1e-6,pz],
                       [0,0,0,1.0      ]])
    right_mode=inverse_result_filter(forward,0.25,0.26,0.08)
    inverse_solution=inverse_angle(forward[0,0],forward[0,1],forward[0,2],forward[0,3],
                                   forward[1,0],forward[1,1],forward[1,2],forward[1,3],
                                   forward[2,0],forward[2,1],forward[2,2],forward[2,3],
                                   0.25,0.26,0.08,right_mode)
    inverse_solution=angle_standard(inverse_solution)
                                
    #print forward
    #print right_mode
    return inverse_solution
