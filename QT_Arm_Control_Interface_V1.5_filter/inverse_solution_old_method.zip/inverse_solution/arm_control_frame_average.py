"""

This part receive data from leapmotion to move the model in rviz.
The difference between current frame(Leap data) and previous frame are used to caculate the movement of the hand.
In order to decrese the collision of the data,few frames(framenum) data are used to get the average one.
@author: shuixin

"""

import rospy,math
import datetime
import time,csv
import Leap
import numpy as np
import inverse_solve
from sensor_msgs.msg import JointState
from std_msgs.msg import Header

def talker():
    global orig_pos_x,orig_pos_y,orig_pos_z,framenum,rad2deg
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)
    rospy.init_node('joint_state_publisher',anonymous=False)
    rate = rospy.Rate(30) # 10hz
    def shutdown():
        global is_run
        is_run=False
        joint_csvfile.close()
        #joint_info.position = [0,0,0,0,0,0]
        print 'rospy shutted down'
    rospy.on_shutdown(shutdown)
    joint_info = JointState()
    joint_info.header = Header()
    joint_info.header.stamp = rospy.Time.now()
    joint_info.name = ['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6' ,'bar1_joint','bar2_joint']
    joint_info.velocity = []
    joint_info.effort = []
    while not rospy.is_shutdown():
        starttime = datetime.datetime.now()
        previous_frame=[]
        for i in range(framenum):
            previous_frame.append(controller.frame(i+framenum))
        current_frame =[]
        for i in range(framenum):
            current_frame.append(controller.frame(i))
        framerate=current_frame[0].current_frames_per_second
        roll=0.0;pitch=0.0;yaw=0.0;pre_pos_x=0.0;pre_pos_y=0.0;pre_pos_z=0.0
        curr_pos_x=0.0;curr_pos_y=0.0;curr_pos_z=0.0
        print 'frame_rate',framerate
        for i in range(framenum):
            for hand in current_frame[i].hands:
                '''
                handType = "Left hand" if hand.is_left else "Right hand"
                print "  %s, id %d, position: %s" % (
                handType, hand.id, hand.palm_position)
                '''
                curr_pos_x+=hand.palm_position[2]
                curr_pos_y+=hand.palm_position[0]
                curr_pos_z+=hand.palm_position[1]
                
                normal = hand.palm_normal
                direction = hand.direction
                arm=hand.arm
                arm_pitch=arm.direction.pitch
                arm_yaw=arm.direction.yaw
                hand_pitch=direction.pitch
                hand_yaw=direction.yaw
                roll+=normal.roll
                pitch+=hand_pitch#-arm_pitch
                yaw+=hand_yaw-arm_yaw
                
            for hand in previous_frame[i].hands:
                global map_factor,map_factor_x,map_factor_y,map_factor_z,q_pre_solution,joint_info_pre
                pre_pos_x+=hand.palm_position[2]
                pre_pos_y+=hand.palm_position[0]
                pre_pos_z+=hand.palm_position[1]
                normal = hand.palm_normal
                direction = hand.direction
                arm=hand.arm
                arm_pitch=arm.direction.pitch
                arm_yaw=arm.direction.yaw
                hand_pitch=direction.pitch
                hand_yaw=direction.yaw
                roll+=normal.roll
                pitch+=hand_pitch#-arm_pitch
                yaw+=hand_yaw-arm_yaw
                #yaw==0.0
        roll=roll/(2*framenum);pitch=pitch/(2*framenum);yaw=yaw/(2*framenum)
        orig_pos_x=orig_pos_x+(curr_pos_x/framenum-pre_pos_x/framenum)*map_factor*map_factor_x
        orig_pos_y=orig_pos_y+(curr_pos_y/framenum-pre_pos_y/framenum)*map_factor*map_factor_y
        orig_pos_z=orig_pos_z+(curr_pos_z/framenum-pre_pos_z/framenum)*map_factor*map_factor_z
        data=data_round(orig_pos_x,orig_pos_y,orig_pos_z,roll*rad2deg,pitch*rad2deg,yaw*rad2deg)
        print 'Leap_Data:x,y,z,roll,pitch,yaw',data
        q=inverse_solve.inverse_solve(data[0],data[1],data[2],data[3]/rad2deg,data[4]/rad2deg,data[5]/rad2deg)
        if q==None:
            print 'Out of Range'
            joint_info.position=joint_info_pre
        else:
            joint_info.position = q_handle(q,0)
            '''
            joint_info.position[3]=0.4*roll
            joint_info.position[5]=0.4*roll
            joint_info.position[4]=pitch-joint_info.position[2]
            '''
            joint_info_pre=joint_info.position
            for i in range(6):
                q_pre_solution[i]=joint_info.position[i]
            print 'joint values:',map(lambda x:round(x*rad2deg,3),joint_info.position)
            endtime = datetime.datetime.now()
            print 'solve_time:',(endtime-starttime).microseconds*1e-6
            #joint_csv_writer.writerow([(endtime-starttime).microseconds*1e-6,joint_info.position[0],joint_info.position[1],joint_info.position[2],joint_info.position[3],joint_info.position[4],joint_info.position[5]])
        joint_info.header.stamp = rospy.Time.now()
        pub.publish(joint_info)
        rate.sleep()

'''
def q_handle(q,q_pre_solution):
    try:
        e=[0.0,0.0,0.0,0.0,0.0,0.0]
        for i in range(6):
            for j in range(6):
                e[i]+=abs(q_pre_solution[j]-q[j,i])
        emin=min(e)
        print emin
        index=e.index(emin)
        joint_info=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
        for i in range(6):
            joint_info[i]=q[i,index]
        joint_info[6]=q[1,index]+q[2,index]
        joint_info[7]=-q[2,index]
        return joint_info
    except:
        print 'q_handle error'
        pass
'''
#the inverse solution q is a 8*6 matrix and each column is a solution
#q_handle renturns one solution and generate extra angle values used in rviz
def q_handle(q,col_num):
    try:
        joint_info=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]#['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6' ,'bar1_joint','bar2_joint']
        for i in range(6):
            joint_info[i]=q[i,col_num]
        joint_info[6]=q[1,col_num]+q[2,col_num]
        joint_info[7]=-q[2,col_num]
        
        joint_info[3]=joint_info[3]+joint_info[5]
        if joint_info[3]>=math.pi:
            joint_info[3]=joint_info[3]%math.pi
            #joint_info[3]=math.pi
        elif joint_info[3]<=-math.pi:
            joint_info[3]=joint_info[3]%(-math.pi)
            #joint_info[3]=-math.pi/2
        joint_info[3]=0.5*joint_info[3]
        joint_info[5]=joint_info[3]
        
        joint_info=q_round(joint_info)
        return joint_info
    except:
        print 'q_handle error'
        pass

#used in q_handle,to round the collision
def q_round(q_solution):
    for i in range(len(q_solution)):
        q_solution[i]=round(q_solution[i],3)
    return q_solution

#to round the origin data received by leapmotion
def data_round(orig_pos_x,orig_pos_y,orig_pos_z,roll,pitch,yaw):
    global xyzaccuracy,rpyaccuracy
    if abs(roll)<8.0:
        roll=0.0
    if abs(pitch)<8.0:
        pitch=0.0
    if abs(yaw)<8.0:
        yaw=0.0
    data=[round(xyzaccuracy*round(orig_pos_x/xyzaccuracy,3),3),round(xyzaccuracy*round(orig_pos_y/xyzaccuracy,3),3),round(xyzaccuracy*round(orig_pos_z/xyzaccuracy,3),3),
          rpyaccuracy*round(roll/rpyaccuracy,0),rpyaccuracy*round(pitch/rpyaccuracy,0),-rpyaccuracy*round(yaw/rpyaccuracy,0)]
    return data


q_pre_solution=[0.0,0.0,0.0,0.0,0.0,0.0]
joint_info_pre=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
framenum=10
rad2deg=180/math.pi
xyzaccuracy=1 #2mm
rpyaccuracy=1 #2 degree
is_run=True
orig_pos_x=0.2192957;orig_pos_y=0.0;orig_pos_z=0.335396
#orig_pos_x=0.35;orig_pos_y=0.0;orig_pos_z=0.45;
#orig_pos_x=0.2812832;orig_pos_y=0.0;orig_pos_z=0.4423231;
pitch=0.0;roll=0.0;yaw=0.0
map_factor=3e-4
map_factor_x=1.0;map_factor_y=-1.0;map_factor_z=-1.0
controller = Leap.Controller()
time.sleep(1)
joint_csvfile=file('Joint_value.csv','wb')
joint_csv_writer=csv.writer(joint_csvfile)
joint_csv_writer.writerow(['time','joint1','joint2','joint3','joint4','joint5','joint6'])
while(is_run):
    if controller.is_connected:
        frame=controller.frame()
        handlist = frame.hands
        if len(handlist)>0:
            talker()
        else:
            print 'No hand detected'
    else:
        print 'Error Detecting LeapMotion,Check the Connection'
        is_run=False


#talker()

#rostopic pub -1 /joint_states sensor_msgs/JointState '{header: auto, name: ['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6'], position: [0.23436, -0.000298, 0.0, 0.0, 0.0, 0.0], velocity: [], effort: []}'


