import rospy,math
import datetime
import time,csv
import Leap
import numpy as np
import inverse_solve
from sensor_msgs.msg import JointState
from std_msgs.msg import Header

def talker():
    global orig_pos_x,orig_pos_y,orig_pos_z,pitch,yaw,roll,framenum,rad2deg,removed_num,joint_info_pre
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)
    rospy.init_node('joint_state_publisher',anonymous=False)
    rate = rospy.Rate(20) # 10hz
    def shutdown():
        global is_run
        is_run=False
        joint_csvfile.close()
        print 'rospy shutted down'
    rospy.on_shutdown(shutdown)
    joint_info = JointState()
    joint_info.header = Header()
    joint_info.header.stamp = rospy.Time.now()
    joint_info.name = ['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6' ,'bar1_joint','bar2_joint']
    joint_info.velocity = []
    joint_info.effort = []
    starttime = datetime.datetime.now()
    while not rospy.is_shutdown():
        
        #starttime = datetime.datetime.now()
        previous_frame=[];pre_data=[]
        for i in range(framenum):
            previous_frame.append(controller.frame(i+framenum))
        current_frame =[];curr_data=[]
        for i in range(framenum):
            current_frame.append(controller.frame(i))
        framerate=current_frame[0].current_frames_per_second
        print 'frame_rate',framerate
        for i in range(framenum):
            for hand in current_frame[i].hands:
                '''
                handType = "Left hand" if hand.is_left else "Right hand"
                print "  %s, id %d, position: %s" % (
                handType, hand.id, hand.palm_position)
                '''
                curr_data.append(hand)

            for hand in previous_frame[i].hands:
                pre_data.append(hand)

        delta_data_filter=data_filter(curr_data,pre_data,framenum,removed_num)
        #print delta_data_filter
        orig_pos_x=orig_pos_x+(delta_data_filter[0])*map_factor_xyz*map_factor_x
        orig_pos_y=orig_pos_y+(delta_data_filter[1])*map_factor_xyz*map_factor_y
        orig_pos_z=orig_pos_z+(delta_data_filter[2])*map_factor_xyz*map_factor_z
        pitch=delta_data_filter[3]*map_factor_rpy
        yaw=delta_data_filter[4]*map_factor_rpy
        roll=delta_data_filter[5]*map_factor_rpy
        #print orig_pos_x,orig_pos_y,orig_pos_z
        data=data_round(orig_pos_x,orig_pos_y,orig_pos_z,roll,pitch,yaw)
        print data        
        q=inverse_solve.inverse_solve(data[0],data[1],data[2],data[3]/rad2deg,data[4]/rad2deg,data[5]/rad2deg)
        #q=inverse_solve.inverse_solve(orig_pos_x,orig_pos_y,orig_pos_z,roll,pitch,-yaw)
        if q==None:
            print 'Out of Range'
            joint_info.position=joint_info_pre
        else:
            #q=inverse_solve.inverse_solve(0.94,0.0,1.445,roll,pitch,yaw)
            joint_info.position = q_handle(q,1)
            joint_info_pre=joint_info.position
            for i in range(6):
                q_joint_angles[i]=round(joint_info.position[i]*rad2deg)
            #print 'joint values',q_joint_angles
            #print joint_info.position
            endtime = datetime.datetime.now()
            print 'solve_time:',(endtime-starttime).microseconds*1e-6
            #joint_csv_writer.writerow([(endtime-starttime).microseconds*1e-6,joint_info.position[0],joint_info.position[1],joint_info.position[2],joint_info.position[3],joint_info.position[4],joint_info.position[5]])
        joint_csv_writer.writerow([(endtime-starttime).microseconds*1e-6,orig_pos_x,orig_pos_y,orig_pos_z,pitch,yaw,roll])
        joint_info.header.stamp = rospy.Time.now()
        pub.publish(joint_info)
        rate.sleep()


def data_filter(curr_data,pre_data,framenum,removed_num):
    try:
        global rad2deg
        return_list=[]
        curr_data_x=[];curr_data_y=[];curr_data_z=[];curr_data_pitch=[];curr_data_yaw=[];curr_data_roll=[]
        pre_data_x=[];pre_data_y=[];pre_data_z=[];pre_data_pitch=[];pre_data_yaw=[];pre_data_roll=[]
        curr_sum_x=0.0;curr_sum_y=0.0;curr_sum_z=0.0;curr_sum_pitch=0.0;curr_sum_yaw=0.0;curr_sum_roll=0.0
        pre_sum_x=0.0;pre_sum_y=0.0;pre_sum_z=0.0;pre_sum_pitch=0.0;pre_sum_yaw=0.0;pre_sum_roll=0.0
        for i in range(framenum):
            curr_data_x.append(curr_data[i].palm_position[2])
            curr_data_y.append(curr_data[i].palm_position[0])
            curr_data_z.append(curr_data[i].palm_position[1])
            
            normal = curr_data[i].palm_normal
            direction = curr_data[i].direction
            arm=curr_data[i].arm
            arm_pitch=arm.direction.pitch
            arm_yaw=arm.direction.yaw
            hand_pitch=direction.pitch
            hand_yaw=direction.yaw
            curr_data_roll.append(normal.roll)
            curr_data_pitch.append(hand_pitch-arm_pitch)
            curr_data_yaw.append(hand_yaw-arm_yaw)
        
        for i in range(framenum):
            pre_data_x.append(pre_data[i].palm_position[2])
            pre_data_y.append(pre_data[i].palm_position[0])
            pre_data_z.append(pre_data[i].palm_position[1])
            
            normal = pre_data[i].palm_normal
            direction = pre_data[i].direction
            arm=pre_data[i].arm
            arm_pitch=arm.direction.pitch
            arm_yaw=arm.direction.yaw
            hand_pitch=direction.pitch
            hand_yaw=direction.yaw
            pre_data_roll.append(normal.roll)
            pre_data_pitch.append(hand_pitch-arm_pitch)
            pre_data_yaw.append(hand_yaw-arm_yaw)  
        
        curr_data_x.sort();curr_data_y.sort();curr_data_z.sort()
        curr_data_pitch.sort();curr_data_yaw.sort();curr_data_roll.sort()
        pre_data_x.sort();pre_data_y.sort();pre_data_z.sort()
        pre_data_pitch.sort();pre_data_yaw.sort();pre_data_roll.sort()
        
        for i in range(framenum-2*removed_num):
            curr_sum_x+=curr_data_x[i+removed_num];curr_sum_y+=curr_data_y[i+removed_num];curr_sum_z+=curr_data_z[i+removed_num]
            curr_sum_pitch+=curr_data_pitch[i+removed_num];curr_sum_yaw+=curr_data_yaw[i+removed_num];curr_sum_roll+=curr_data_roll[i+removed_num]
            pre_sum_x+=pre_data_x[i+removed_num];pre_sum_y+=pre_data_y[i+removed_num];pre_sum_z+=pre_data_z[i+removed_num]
            pre_sum_pitch+=pre_data_pitch[i+removed_num];pre_sum_yaw+=pre_data_yaw[i+removed_num];pre_sum_roll+=pre_data_roll[i+removed_num]
        
        delta_x=(curr_sum_x-pre_sum_x)/(framenum-2*removed_num)
        delta_y=(curr_sum_y-pre_sum_y)/(framenum-2*removed_num)
        delta_z=(curr_sum_z-pre_sum_z)/(framenum-2*removed_num)
        pitch=rad2deg*(curr_sum_pitch+pre_sum_pitch)/(framenum-2*removed_num)/2
        yaw=rad2deg*(curr_sum_yaw+pre_sum_yaw)/(framenum-2*removed_num)/2
        roll=rad2deg*(curr_sum_roll+pre_sum_roll)/(framenum-2*removed_num)/2
        return_list.extend([delta_x,delta_y,delta_z,pitch,yaw,roll])
        return return_list
    except:
        print 'data_filter error'
        pass
    
    
def data_round(orig_pos_x,orig_pos_y,orig_pos_z,roll,pitch,yaw):
    global xyzaccuracy,rpyaccuracy
    if abs(roll)<5.0:
        roll=0.0
    if abs(pitch)<8.0:
        pitch=0.0
    if abs(yaw)<5.0:
        yaw=0.0
    data=[round(xyzaccuracy*round(orig_pos_x/xyzaccuracy,3),3),round(xyzaccuracy*round(orig_pos_y/xyzaccuracy,3),3),round(xyzaccuracy*round(orig_pos_z/xyzaccuracy,3),3),
          rpyaccuracy*round(roll/rpyaccuracy,0),rpyaccuracy*round(pitch/rpyaccuracy,0),-rpyaccuracy*round(yaw/rpyaccuracy,0)]
    return data

def q_handle(q,col_num):
    try:
        joint_info=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
        for i in range(6):
            joint_info[i]=q[i,col_num]
        joint_info[6]=q[1,col_num]+q[2,col_num]
        joint_info[7]=-q[2,col_num]
        joint_info=q_round(joint_info)
        return joint_info
    except:
        print 'q_handle error'
        pass

def q_round(q_solution):
    for i in range(len(q_solution)):
        q_solution[i]=round(q_solution[i],3)
    return q_solution




q_joint_angles=[0.0,0.0,0.0,0.0,0.0,0.0]
joint_info_pre=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
pre_data=[]
curr_data=[]
framenum=6
removed_num=1
rad2deg=180/math.pi
xyzaccuracy=1 #2mm
rpyaccuracy=1 #2 degree
is_run=True
orig_pos_x=0.2192957;orig_pos_y=0.0;orig_pos_z=0.335396
#orig_pos_x=0.35;orig_pos_y=0.0;orig_pos_z=0.45;
#orig_pos_x=0.2812832;orig_pos_y=0.0;orig_pos_z=0.4423231;
pitch=0.0;roll=0.0;yaw=0.0
map_factor_xyz=4e-4
map_factor_rpy=1
map_factor_x=1.0;map_factor_y=-1.0;map_factor_z=-1.0
controller = Leap.Controller()
time.sleep(1.0)
joint_csvfile=file('data_value.csv','wb')
joint_csv_writer=csv.writer(joint_csvfile)
joint_csv_writer.writerow(['time','x','y','z','pitch','yaw','roll'])
while(is_run):
    if controller.is_connected:
        frame=controller.frame()
        handlist = frame.hands
        if len(handlist)>0:
            talker()
        else:
            print 'No hand detected'
    else:
        print 'Error Detecting LeapMotion,Check the Connection'
        is_run=False


#talker()

#rostopic pub -1 /joint_states sensor_msgs/JointState '{header: auto, name: ['joint_1', 'joint_2', 'joint_3', 'joint_4', 'joint_5', 'joint_6'], position: [0.23436, -0.000298, 0.0, 0.0, 0.0, 0.0], velocity: [], effort: []}'


