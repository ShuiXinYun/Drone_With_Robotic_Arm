# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:53:57 2016

@author: shuixin
"""

import numpy as np
def q_filter(q):
    global q_solution
    e=[0.0,0.0,0.0,0.0]
    for i in range(4):
        for j in range(4):
            e[i]+=abs(q_solution[j]-q[j,i])
    emin=min(e)
    print emin
    index=e.index(emin)
    return index
q_solution=[0.0,0.0,0.0,0.0]
q=np.matrix([[0.1,2,3,4],[0.2,2,3,4],[0.3,2,3,4],[0.4,2,3,4]])
print q_filter(q)